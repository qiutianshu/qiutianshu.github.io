#include "heap.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>

#ifndef NOLEAK
#define NOLEAK (8)
#endif

#define ORIGIN  0

int main() {
    void * chunk = mmap((void *)0x1004000, 0x100000, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    printf("chunk = %p\n", chunk);
    heap_add_chunk(chunk, 0x100000, 1);
    _malloc(0x3c0);         // alignment of the low order bytes of addresses in SecureRAM
    void * descs[10];
    void * io_req[100];
    descs[0] = _malloc(234);
    descs[1] = _malloc(22);
    descs[2] = _malloc(62);
    descs[3] = _malloc(198);
    descs[4] = _malloc(62);

    const int N = NOLEAK;

    void * task = _malloc(0x3c0);
//    void * task_stack = _malloc(0x4000);
    void * task_stack = _malloc(0x1000);

    void * io_buf_0 = memalign(0x800, 0x40);
    void * hs = _malloc(25);
    void * fs = _malloc(25);

    void * zlps[2];

    for(int i = 0; i < N; i++)
    {
        io_req[i] = _malloc(0x30);
    }

#if ORIGIN
    for(int i = 0; i < N; i++)
    {
        if(i < 2)
        {
            zlps[i] = _malloc(0x30);
        }
        _free(io_req[i]);
    }
#else    
    for(int i = 0; i < N; i++){
        if(i == 0)
            zlps[0] = _malloc(0x30);
        if(i == 6)
            zlps[1] = _malloc(0x30);
        
        _free(io_req[i]);
    }
#endif

    for(int i = 0; i < 5; i++)
    {
       printf("descs[%d]  = %p\n", i, descs[i]);
    }

    printf("task = %p\n", task);
    printf("task_stack = %p\n", task_stack);
    printf("io_buf = %p\n", io_buf_0);
    printf("hs = %p\n", hs);
    printf("fs = %p\n", fs);

    for(int i = 0; i < 2; i++)
    {
       printf("zlps[%d]  = %p\n", i, zlps[i]);
    }

    printf("**********\n");

    for(int i = 0; i < 5; i++)
    {
        _free(descs[i]);
    }

    _free(task);
    _free(task_stack);
    _free(io_buf_0);
    _free(hs);
    _free(fs);

    descs[0] = _malloc(234);
    descs[1] = _malloc(22);
    descs[2] = _malloc(62);
    descs[3] = _malloc(198);
    descs[4] = _malloc(62);

    task = _malloc(0x3c0);
//    task_stack = _malloc(0x4000);
    task_stack = _malloc(0x1000);
    void * io_buf_1 = memalign(0x800, 0x40);
    hs = _malloc(25);
    fs = _malloc(25);

    for(int i = 0; i < 5; i++)
    {
       printf("descs[%d]  = %p\n", i, descs[i]);
    }

    printf("task = %p\n", task);
    printf("task_stack = %p\n", task_stack);
    printf("io_buf = %p\n", io_buf_1);
    printf("hs = %p\n", hs);
    printf("fs = %p\n", fs);

    for(int i = 0; i < 5; i++)
    {
        io_req[i] = _malloc(0x30);
        printf("io_req[%d] = %p\n", i, io_req[i]);
    }

    printf("**********\n");
    printf("io_req_off = %#lx\n", (int64_t)io_req[0] - (int64_t)io_buf_0);
    printf("hs_off  = %#lx\n", (int64_t)hs - (int64_t)io_buf_0);
    printf("fs_off  = %#lx\n", (int64_t)fs - (int64_t)io_buf_0);

    return 0;
}