#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#define HEAP_ENTROPY_MASK		(0xfffUL)
#define HEAP_BLOCK_SIZE		(64)
#define HEAP_DEBUGGING		0
#define HEAP_CHECKS		1
#define HEAP_COOKIE_SIZE	16

#define offsetof(TYPE, MEMBER)	__builtin_offsetof (TYPE, MEMBER)
#define __return_address(_x)	__builtin_return_address(_x)
#define HEAP_PANIC(b, x) heap_panic(__func__, b, x)

typedef uint64_t utime_t;

struct heap_block
{
	// checksum of all members excep _pad, includes next_in_bin and prev_in_bin iff this_free is set
	uint64_t checksum;
	/*
	 * In order to get allocations that are cacheline-sized, we have to blow an entire line
	 * on the heap block.  This is a bit inefficient, but allocations need to be I/O safe.
	 */
	uint32_t _pad[(HEAP_BLOCK_SIZE - 4 * __SIZEOF_SIZE_T__ - 8) / 4];    //(64 - 4 * 8 - 8) / 4 = 24 / 4 = 6 uint32_t _pad[6];
	// size of this block in units of sizeof(struct heap_block)
	size_t  this_size;
	size_t  this_free:1;      						//第5个unsigned long 的第0bit
	size_t  prev_free:1;							//第5个unsigned long 的第1bit
	// size of the previous block in units of sizeof(struct heap_block),
	// allows the location of the previous block header to be found
	size_t  prev_size:(__SIZE_WIDTH__ - 2);			//第5个unsigned long 的剩下62bits
	// offset from beginning of block to padding
	size_t  padding_start;
	size_t  padding_bytes;
};

struct free_block
{
	struct heap_block  common;
	struct free_block *next_in_bin;
	struct free_block *prev_in_bin;
};

struct client_data
{
	uint32_t block_type;
	void    *requestor;
	const char *requestor_name;
	utime_t  timestamp;

	uint32_t user_size;
	uint32_t alignment;
};

struct chunk_data
{
	struct heap_block *chunk_base;
	uint32_t           chunk_size;
};

enum
{
	NUM_CHUNKS = 4,
	NUM_BINS = 32,
};

enum
{
	HEAP_BLOCK__FREE,
	HEAP_BLOCK__MALLOC,
	HEAP_BLOCK__MEMALIGN,
	HEAP_BLOCK__SENTINEL,
};

#define ROUNDUPTO(num, gran)        ((((num) + (gran) - 1) / (gran)) * (gran))
#define ROUNDUP(a, b) (((a) + ((b) - 1)) & (~((b) - 1)))

typedef unsigned long		uintptr_t;
typedef unsigned int		uint32_t;
typedef uint64_t 			utime_t;
typedef unsigned char		uint8_t;

uint64_t g_heap_cookie[HEAP_COOKIE_SIZE] = { 0x64636b783132322fULL, 0xa7fa3a2e367917fcULL };
static int                 chunk_count;
static struct chunk_data   lead[NUM_CHUNKS];
static struct free_block   bins[NUM_BINS];
static uint32_t	   free_mem;

void bzero(void *dst, size_t size){
	memset(dst, 0, size);
}

static void heap_panic(char const *func, const void *block, const char *reason)
{
	printf("%s: heap error: %s : please enable HEAP_PANIC_CHECKS\n", func, reason);
	while(1){}
}

static size_t required_size_for_split(size_t size)
{
	size += sizeof(struct free_block);

	return size;
}

static size_t round_size(size_t size)
{
	return (size + sizeof(struct heap_block) - 1) & ~(sizeof(struct heap_block) -1);
}

static size_t dequantify_size(size_t size)
{
	return size*sizeof(struct heap_block);
}

static size_t quantify_size(size_t size)
{
	return size/sizeof(struct heap_block);
}

static unsigned compute_bin(size_t size)
{
	unsigned result;
	
	size = quantify_size(size);
	if(size < 1){
		printf("size < 1 %s\n", __FUNCTION__);
		while(1){}
	}

	// clz can't operate on > 32-bit values, so return an invalid bin
	// number to force grab_chunk to fail and free_list_add to assert
	if ((uint64_t)size > UINT32_MAX) {
		return NUM_BINS;
	}

	result = NUM_BINS - __builtin_clz((uint32_t)size);
	if(result >= NUM_BINS){
		printf("result >= NUM_BINS %s\n", __FUNCTION__);
		while(1){}
	}

	return result;
}

static size_t sizeof_block(struct heap_block *b)
{
	return dequantify_size(b->this_size);
}

static void * advance_pointer(void const *p, size_t stride)
{
	uintptr_t val;

	val = (uintptr_t)(p);
	val += stride;

	return (void*)(val);
}

static void * recess_pointer(void const *p, size_t stride)
{
	uintptr_t val;

	val = (uintptr_t)(p);
	val -= stride;

	return (void*)(val);
}


static void *next_block(struct heap_block const *b)
{
	return advance_pointer(b, dequantify_size(b->this_size));
}

static void * prev_block(struct heap_block const *b)
{
	return recess_pointer(b, dequantify_size(b->prev_size));
}

static void pad_block(struct heap_block *b, size_t user_size)
{
#if HEAP_CHECKS
	uint8_t *pad_start = advance_pointer(b + 1, user_size);
	uint8_t *pad_end = (uint8_t *)next_block(b);
	size_t padding;
	
#if HEAP_DEBUGGING
	pad_end -= round_size(sizeof(struct client_data));
#endif

	padding = (pad_end - pad_start);

	b->padding_bytes = padding;
	b->padding_start = pad_start - (uint8_t *)b;

	for (size_t i = 0; i < padding; i++) {
		*(pad_end - 1 - i) = (uint8_t)((size_t)-1 - i);
	}

	// Also zero out the padding section of the heap block's
	// header
	memset(b->_pad, 0, sizeof(b->_pad));
#endif
}

static size_t required_size(size_t size)
{
	size += 2*sizeof(struct heap_block) - 1;
	
	if (size < (2*sizeof(struct heap_block) - 1)) {
		printf("integer overflow in required_size\n");
		while(1){}
	}

	size &= ~(sizeof(struct heap_block) - 1);

	if (size < sizeof(struct free_block)) {
		size = sizeof(struct free_block);
	}

	return size;
}

#define cROUNDS 2
#define dROUNDS 4
#define ROTL(x,b) (uint64_t)( ((x) << (b)) | ( (x) >> (64 - (b))) )
#define SIPROUND            \
	do {              \
		v0 += v1; v1=ROTL(v1,13); v1 ^= v0; v0=ROTL(v0,32); \
		v2 += v3; v3=ROTL(v3,16); v3 ^= v2;     \
		v0 += v3; v3=ROTL(v3,21); v3 ^= v0;     \
		v2 += v1; v1=ROTL(v1,17); v1 ^= v2; v2=ROTL(v2,32); \
	} while(0)

void siphash_aligned(uint64_t *out, const uint64_t *in_aligned, size_t inlen, const uint64_t *k)
{
	/* "somepseudorandomlygeneratedbytes" */
	uint64_t v0 = 0x736f6d6570736575ULL;
	uint64_t v1 = 0x646f72616e646f6dULL;
	uint64_t v2 = 0x6c7967656e657261ULL;
	uint64_t v3 = 0x7465646279746573ULL;
	uint64_t b;
	uint64_t k0 = k[0];
	uint64_t k1 = k[1];
	uint64_t m;
	int i;
	const uint8_t *in = (const uint8_t *)in_aligned;
	const uint8_t *end = in + inlen - ( inlen % sizeof( uint64_t ) );
	const int left = inlen & 7;
	b = ( ( uint64_t )inlen ) << 56;
	v3 ^= k1;
	v2 ^= k0;
	v1 ^= k1;
	v0 ^= k0;

	if(((uintptr_t)in_aligned & (sizeof(uint64_t) - 1)) != 0){
		printf("(uintptr_t)in_aligned & (sizeof(uint64_t) - 1 != 0 %s\n", __FUNCTION__);
		while(1){}
	}

	for ( ; in != end; in += 8 )
	{
		m = *(uint64_t *)in;
		v3 ^= m;

		for( i=0; i<cROUNDS; ++i ) SIPROUND;

		v0 ^= m;
	}

	switch( left )
	{
		case 7: b |= ( ( uint64_t )in[ 6] )  << 48;

		case 6: b |= ( ( uint64_t )in[ 5] )  << 40;

		case 5: b |= ( ( uint64_t )in[ 4] )  << 32;

		case 4: b |= ( ( uint64_t )in[ 3] )  << 24;

		case 3: b |= ( ( uint64_t )in[ 2] )  << 16;

		case 2: b |= ( ( uint64_t )in[ 1] )  <<  8;

		case 1: b |= ( ( uint64_t )in[ 0] ); break;

		case 0: break;
	}

	v3 ^= b;

	for( i=0; i<cROUNDS; ++i ) SIPROUND;

	v0 ^= b;
	v2 ^= 0xff;

	for( i=0; i<dROUNDS; ++i ) SIPROUND;

	b = v0 ^ v1 ^ v2  ^ v3;
	*out = b;
}

static void verify_block_checksum(struct heap_block const *b)
{
#if HEAP_CHECKS
	uint64_t checksum;
	size_t checksumlen = sizeof(struct heap_block) - offsetof(struct heap_block, this_size);
	if (b->this_free)
		checksumlen += sizeof(struct free_block) - sizeof(struct heap_block);

	siphash_aligned((uint64_t *)&checksum, (const uint64_t *)&b->this_size, checksumlen, g_heap_cookie);

	if (checksum != b->checksum) {
		HEAP_PANIC(b, "bad block checksum");
	}
#endif
}

static void calculate_block_checksum(struct heap_block* b){
	size_t checksumlen = sizeof(struct heap_block) - offsetof(struct heap_block, this_size);
	if (b->this_free)
		checksumlen += sizeof(struct free_block) - sizeof(struct heap_block);
	siphash_aligned((uint64_t *)&b->checksum, (const uint64_t *)&b->this_size, checksumlen, g_heap_cookie);
}

static void verify_block_padding(struct heap_block const *b)
{
#if HEAP_CHECKS
	size_t padding = b->padding_bytes;
	if (padding) {
		uint8_t *pad_end = (uint8_t *)b + b->padding_start + padding;

		for(size_t i = 0; i < padding; i++) {
			if (*(pad_end - 1 - i) != (uint8_t)((size_t)-1 - i)) {
				HEAP_PANIC(b, "bad padding");
			}
		}
	}

	// Also verify the padding inside the heap block metadata
	for (size_t i = 0; i < sizeof(b->_pad) / sizeof(b->_pad[0]); i++) {
		if (b->_pad[i] != 0) {
			HEAP_PANIC(b, "bad padding");
		}
	}
#endif
}

static void free_list_remove(struct free_block *b)
{
	if (b->prev_in_bin == b)
		HEAP_PANIC(b, "free list unlink error");
	if (b->next_in_bin == b)
		HEAP_PANIC(b, "free list unlink error");
	if (b->prev_in_bin->next_in_bin != b)
		HEAP_PANIC(b, "free list unlink error");
	if (b->next_in_bin && b->next_in_bin->prev_in_bin != b)
		HEAP_PANIC(b, "free list unlink error");

	verify_block_checksum(&b->prev_in_bin->common);
	b->prev_in_bin->next_in_bin = b->next_in_bin;
	calculate_block_checksum(&b->prev_in_bin->common);

	if (b->next_in_bin) {
		verify_block_checksum(&b->next_in_bin->common);
		b->next_in_bin->prev_in_bin = b->prev_in_bin;
		calculate_block_checksum(&b->next_in_bin->common);
	}
}

static struct heap_block * merge_blocks_left(struct heap_block *left, struct heap_block *right)
{
	// caller will add the new block back into the free list
	// (possibly in a new bin to reflect the larger size)
	free_list_remove((struct free_block *)(left));

	left->this_size += right->this_size;

	if (HEAP_CHECKS) {
		// the right block is going away, so make sure it no longer
		// looks like a real block
		right->this_size = 0;
		right->prev_size = 0;
		right->checksum = 0;
	}

	return left;
}

static struct heap_block *merge_blocks_right(struct heap_block *left, struct heap_block *right)
{
	free_list_remove((struct free_block *)(right));

	left->this_size += right->this_size;

	if (HEAP_CHECKS) {
		// the right block is going away, so make sure it no longer
		// looks like a real block
		right->this_size = 0;
		right->prev_size = 0;
		right->checksum = 0;
	}

	return left;
}

static void fixup_next_after_free(struct heap_block *block)
{
	struct heap_block *next;

	next = next_block(block);
	verify_block_checksum(next);

	next->prev_free = 1;
	next->prev_size = block->this_size;

	calculate_block_checksum(next);
}

static void free_list_add(struct free_block *b)
{
	struct free_block *bin;
	unsigned bin_num;

	bin_num = compute_bin(sizeof_block(&b->common));
	if(bin_num >= NUM_BINS){
		printf("bin_num >= NUM_BINS %s\n", __FUNCTION__);
		while(1){}
	}

	bin = bins + bin_num;

	b->next_in_bin = bin->next_in_bin;
	b->prev_in_bin = bin;
	if (bin->next_in_bin) {
		if (bin->next_in_bin == bin)
			HEAP_PANIC(bin, "free list unlink error");
		if (bin->next_in_bin->prev_in_bin != bin)
			HEAP_PANIC(bin, "free list unlink error");

		verify_block_checksum(&bin->next_in_bin->common);
		bin->next_in_bin->prev_in_bin = b;
		calculate_block_checksum(&bin->next_in_bin->common);
	}
	bin->next_in_bin = b;

	calculate_block_checksum(&bin->common);
}

static void *split_head(struct heap_block *b, size_t size)
{
	if (!size) {
		return b;
	} else if (size < sizeof(struct free_block)) {
		/*
		 * the preamble is too small to contain a free block
		 * so we just append the preamble to the previous block
		 *
		 * and edge condition would be that this block is the
		 * first one, but this situation is skipped by making
		 * sure the arena starts at an address congurent with
		 * the size of a free block
		 */
		struct heap_block *prev;
		struct heap_block *next;
		struct heap_block *retval;

		prev = prev_block(b);
		verify_block_checksum(prev);
		next = next_block(b);
		verify_block_checksum(next);

		retval = advance_pointer(b, size);

		prev->this_size += quantify_size(size);
		next->prev_size -= quantify_size(size);

		retval->prev_free = b->prev_free;
		retval->this_free = b->this_free;
		retval->prev_size = b->prev_size + quantify_size(size);
		retval->this_size = b->this_size - quantify_size(size);

		calculate_block_checksum(retval);
		calculate_block_checksum(prev);
		calculate_block_checksum(next);

		return retval;
	} else {
		struct heap_block *next;
		struct heap_block *retval;

		next = next_block(b);
		verify_block_checksum(next);

		retval = advance_pointer(b, size);

		next->prev_size -= quantify_size(size);

		retval->prev_free = 1;
		retval->this_free = b->this_free;
		retval->prev_size = quantify_size(size);
		retval->this_size = b->this_size - quantify_size(size);

		b->this_free = 1;
		b->this_size = quantify_size(size);
		free_list_add((struct free_block *)b);

		calculate_block_checksum(b);
		calculate_block_checksum(retval);
		calculate_block_checksum(next);

		return retval;
	}
}

static void split_tail(struct heap_block *b, size_t size, size_t user_size)
{
	struct heap_block *next_one;
	size_t block_size;

	verify_block_checksum(b);

	next_one = next_block(b);
	verify_block_checksum(next_one);

	block_size = sizeof_block(b);

	if (block_size >= required_size_for_split(size)) {
		struct free_block *remainder;

		remainder = advance_pointer(b, size);

		remainder->common.prev_free = 0;
		remainder->common.this_free = 1;
		remainder->common.prev_size = quantify_size(size);
		remainder->common.this_size = b->this_size - remainder->common.prev_size;
		free_list_add(remainder);
		calculate_block_checksum(&remainder->common);

		b->this_size = quantify_size(size);

		next_one->prev_size = remainder->common.this_size;
	} else {
		next_one->prev_free = 0;
	}

	b->this_free = 0;

	pad_block(b, user_size);

	calculate_block_checksum(b);
	calculate_block_checksum(next_one);
}

static void *grab_chunk(size_t size, size_t user_size)
{
	size_t bin;

	for (bin= compute_bin(size); bin< NUM_BINS; bin++) {
		struct free_block *curr;

		// the first element of the list isn't a real free block; it just guarantees
		// every real free block has a previous block
		curr = &bins[bin];
		curr = curr->next_in_bin;

		// iterate the real blocks in the bin
		while (curr) {
			if (sizeof_block(&curr->common) >= size) {
				verify_block_checksum(&curr->common);

				// take the current block out of its bin
				free_list_remove(curr);
				// if possible, add back any unneeded part of the
				// current block to the appropriate bin;
				split_tail(&curr->common, size, user_size);

				return curr;
			}

			curr = curr->next_in_bin;
		}
	}

	printf("heap overflow %s\n", __FUNCTION__);
	while(1){}

	return NULL;
}

// used by heap_memalign to find a chunk of memory whose base satisfies
// the given alignment constraint
static void *grab_chunk__constrained(size_t size, size_t constraint, size_t user_size)
{
	size_t bin;

	// search through all the bins, skipping any that are guaranteed to be too small
	for (bin= compute_bin(size); bin< NUM_BINS; bin++) {
		struct free_block *curr;

		// the first element of the list isn't a real free block; it just guarantees
		// every real free block has a previous block
		curr = &bins[bin];
		curr = curr->next_in_bin;

		// iterate the real blocks in the bin
		while (curr) {
			uintptr_t base;
			uintptr_t limit;
			size_t usable_size;

			// calculate the address of the memory the candidate block holds rounded up to
			// required alignment
			base = ((uintptr_t)(curr) + sizeof(struct heap_block) + constraint - 1) & ~(constraint - 1);
			// and then figure out where the metadata for memory at the required
			// alignment would sit
			base -= sizeof(struct heap_block);

			// the address of the block following the candidate block
			limit = (uintptr_t)(curr) + sizeof_block(&curr->common);

			// first condition, aligned address can't be past the end of the candidate block
			if (base < limit) {
				// if the requested amount of memory is available between the aligned address
				// and the end of the block, we're good
				usable_size = limit - base;
				if (usable_size >= size) {
					verify_block_checksum(&curr->common);

					// pull this block out of its bin
					free_list_remove(curr);

					// put the unused portions of the block before and after
					// the aligned address onto the appropriate free lists
					curr = split_head(&curr->common, base - (uintptr_t)(curr));
					split_tail(&curr->common, size, user_size);

					return curr;
				}
			}

			curr = curr->next_in_bin;
		}
	}

#if HEAP_ERROR_PANIC
	panic("heap overflow");
#endif
	return NULL;
}
