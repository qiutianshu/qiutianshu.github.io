#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "util.h"

void heap_free(void *ptr){
	struct heap_block *block;
	struct heap_block *left;
	struct heap_block *right;

	if (!ptr) {
		return;
	}

	block = ptr;
	block -= 1;

	free_mem += sizeof_block(block);

	verify_block_checksum(block);

	left = prev_block(block);
	right = next_block(block);

	if (HEAP_CHECKS) {
		if (right == block) {
			HEAP_PANIC(block, "unlink error this_size");
		}
		if (left == block) {
			HEAP_PANIC(block, "unlink error prev_size");
		}
		if (prev_block(right) != block) {
			HEAP_PANIC(block, "unlink error next's prev_size");
		}
		if (next_block(left) != block) {
			HEAP_PANIC(block, "unlink error prev's this_size");
		}
		if (block->this_free) {
			HEAP_PANIC(block, "double free");
		}

		if (block->prev_free && !left->this_free) {
			HEAP_PANIC(block, "free bit corrupted");
		}

		verify_block_padding(block);

		// zero the block to detect use after free
		memset(block + 1, 0, sizeof_block(block) - sizeof(*block));

		block->this_free = 1;
	}

	if (block->prev_free) {
		verify_block_checksum(left);
		block = merge_blocks_left(left, block);
	}

	verify_block_checksum(right);
	if (right->this_free) {
		block = merge_blocks_right(block, right);
	}

	fixup_next_after_free(block);

	block->this_free = 1;
	free_list_add((struct free_block *)block);
	calculate_block_checksum(block);
}

void heap_add_chunk(void *chunk, size_t size, bool clear_memory)
{
	struct heap_block *front_sentinel;
	struct heap_block *slab;
	struct heap_block *back_sentinel;
	uintptr_t chunk_base;
	size_t original_size;
	size_t minimum_size_for_slide;


	if(sizeof(struct heap_block) != HEAP_BLOCK_SIZE){
		printf("sizeof(struct heap_block) != HEAP_BLOCK_SIZE %s", __FUNCTION__);
		while(1){}
	}

	if (chunk_count >= NUM_CHUNKS){      			//最多不能超过4个chunk
		printf("too many heap chunks (max %d\n)", NUM_CHUNKS);
		while(1){}
	}

	/* unless the caller knowns the chunk is all zeroes, clear it */
	if (clear_memory)								//清空整个heap。传入的参数chunk=heap_base=0x1801B4000, size=heap_size=0x4C000
		bzero(chunk, size);

	/* align the passed-in chunk and size */
	original_size = size;
	chunk_base = ROUNDUP((uintptr_t)chunk, sizeof(struct heap_block));//(0x1801B4000 + 63) & (~63) = 0x1801B4000
	size -= chunk_base - (uintptr_t)chunk;		//64bytes align
	chunk = (void *)chunk_base;
	size = round_size(size);//(0x4c000 + 63) & (~63) = 0x4c000
															

	/* build out the chunk */
	lead[chunk_count].chunk_base = chunk;				              				//直接到了这里
	lead[chunk_count].chunk_size = size;
	chunk_count++;

	/* front sentinel */
	front_sentinel = chunk;
	front_sentinel->prev_free = 0;
	front_sentinel->this_free = 0;
	front_sentinel->prev_size = 0;
	front_sentinel->this_size = 1;
	front_sentinel->padding_bytes = 0;
	calculate_block_checksum(front_sentinel);

	/* free space */
	slab = next_block(front_sentinel);
	slab->prev_free = 0;
	slab->this_free = 0;
	slab->prev_size = 1;
	slab->this_size = quantify_size(size) - 2;
	slab->padding_bytes = 0;
	calculate_block_checksum(slab);

	/* back sentinel */
	back_sentinel = next_block(slab);
	back_sentinel->prev_free = 0;
	back_sentinel->this_free = 0;
	back_sentinel->prev_size = slab->this_size;
	back_sentinel->this_size = 1;
	back_sentinel->padding_bytes = 0;
	calculate_block_checksum(back_sentinel);

	/* free the free space back into the heap */
	heap_free(slab + 1);
}

void *heap_malloc(size_t size, const char *caller_name){
	size_t size_r;
	size_t size_d;
	struct heap_block *retval;

	/* must allocate at least one byte */
	if (size < 1) {
		printf("heap_malloc must allocate at least one byte %s\n", __FUNCTION__);
		while(1){}
	}
	
	size_r = required_size(size);
	if (HEAP_DEBUGGING) {
		size_d = round_size(sizeof(struct client_data));
	} else {
		size_d = 0;
	}
	retval = grab_chunk(size_r + size_d, size);

	free_mem -= sizeof_block(retval);

	if (retval) {
		retval += 1;
		memset(retval, 0, size);
		return retval;
	} else {
		return NULL;
	}
}

void *heap_memalign(size_t size, size_t constraint, const char *caller_name)
{
	size_t size_r;
	size_t size_d;
	struct heap_block *retval;

	/* must allocate at least one byte */
	if (size < 1) {
		printf("_memalign must allocate at least one byte %s\n", __FUNCTION__);
		while(1){}
	}

	if (constraint & (constraint-1)) {
		/* alignment must be a power of two */
		printf("_memalign must be a power of two %s\n", __FUNCTION__);
		while(1){}
	}

	if (constraint < sizeof(struct free_block)) {
		constraint = sizeof(struct free_block);
	}

	size_r = required_size(size);
	if (HEAP_DEBUGGING) {
		size_d = round_size(sizeof(struct client_data));
	} else {
		size_d = 0;
	}
	retval = grab_chunk__constrained(size_r + size_d, constraint, size);

	free_mem -= sizeof_block(retval);

	if (retval) {
		retval += 1;
		memset(retval, 0, size);
		return retval;
	} else {
		return NULL;
	}
}
