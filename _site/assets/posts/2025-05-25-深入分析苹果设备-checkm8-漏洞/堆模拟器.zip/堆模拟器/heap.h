#include <stdlib.h>
#include <stdbool.h>

#define _malloc(_s)		heap_malloc(_s, NULL)
#define _free(_p)        heap_free(_p)
#define memalign(_s, _a)	heap_memalign(_s, _a, NULL)

void *heap_malloc(size_t size, const char *caller_name);
void heap_add_chunk(void *chunk, size_t size, bool clear_memory);
void *heap_memalign(size_t size, size_t constraint, const char *caller_name);
void heap_free(void *ptr);